#include <iostream>
#include "wangzhe.h"
using namespace std; 

void wangzhe ::showd()
{
cout<<"Ӣ��Ѫ��:";cout<<m1 <<endl;
cout<<"Ӣ������:";cout<< m2 <<endl;
}
wangzhe::~wangzhe ()
{
cout<<"����"<<endl ;
};

wangzhe::wangzhe( int j1,int n1)
{
	
   m1=j1;
   m2=n1 ;
}
void wangzhe::at()
{
m1= m1-50;
}
void wangzhe::xuelaing()
{
	m1 =m1+20;
	m2 =m2-20;
}
