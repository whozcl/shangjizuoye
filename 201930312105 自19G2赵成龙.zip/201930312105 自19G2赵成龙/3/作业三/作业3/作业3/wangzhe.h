#include <iostream>

using namespace std;

class wangzhe
{
public:
        wangzhe();
		wangzhe( int jl,int n1);
		void showd();
		void xuelaing();
		void at();
		~wangzhe();
		int m1;
	    int m2;
};
