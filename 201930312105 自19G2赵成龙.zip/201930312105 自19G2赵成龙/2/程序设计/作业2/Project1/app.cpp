#include <iostream>
#include"add.h"
using namespace std; 
void finish()
{
cout<<"���"<<endl;
}