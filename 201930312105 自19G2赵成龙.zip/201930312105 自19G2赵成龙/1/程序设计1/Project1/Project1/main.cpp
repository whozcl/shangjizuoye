#include<iostream>
using namespace std;
int main()
{
	cout<<"Here is my student number;"<<endl;
	cout<<"****   *****"<<endl;
	cout<<"*  *   *    "<<endl;
	cout<<"*  *   *****"<<endl;
	cout<<"*  *       *"<<endl;
	cout<<"****   *****"<<endl;
	
	return 0;
}
